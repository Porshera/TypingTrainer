"""
Тесты тренажёра слепой печати
Запуск: pytest test_typing_trainer.py -v
"""
import json, os, sys, time
import pytest 

sys.path.insert(0, os.path.dirname(__file__))

from analyzer import Analyzer
from validator import Validator
from storage import Storage
from text_manager import TextManager, BuiltInTexts, TEXT_SIZES


# ── Analyzer ──────────────────────────────────────────────────────────────────

def test_analyzer_initial():
    a = Analyzer()
    assert a.cpm() == 0 and a.accuracy() == 100.0 and a.elapsed() == 0.0

def test_analyzer_tap_counts():
    a = Analyzer(); a.start()
    a.tap(True); a.tap(True); a.tap(False)
    assert a.total == 3 and a.correct == 2

def test_analyzer_accuracy():
    a = Analyzer(); a.start()
    a.tap(True); a.tap(False)
    assert a.accuracy() == 50.0

def test_analyzer_elapsed_freezes_after_stop():
    a = Analyzer(); a.start(); time.sleep(0.05); a.stop()
    t = a.elapsed(); time.sleep(0.05)
    assert a.elapsed() == t

def test_analyzer_wpm_is_cpm_div_5():
    a = Analyzer(); a.start()
    for _ in range(50): a.tap(True)
    assert a.wpm() == a.cpm() // 5

def test_analyzer_stats_keys():
    a = Analyzer(); a.start(); a.tap(True)
    assert all(k in a.stats() for k in ('cpm', 'wpm', 'accuracy', 'total', 'correct', 'errors', 'time'))


# ── Validator ─────────────────────────────────────────────────────────────────

def test_validator_strips_whitespace():
    assert Validator("  hi  ").text == "hi"

def test_validator_correct_char():
    v = Validator("abc")
    ok, _ = v.check("a")
    assert ok and v.pos == 1 and v.status[0] == 'correct'

def test_validator_wrong_char():
    v = Validator("abc")
    ok, _ = v.check("x")
    assert not ok and v.pos == 0 and v.status[0] == 'incorrect'
    assert v.errors[0] == {'pos': 0, 'expected': 'a', 'got': 'x'}

def test_validator_done_and_accuracy():
    v = Validator("hi")
    v.check("h"); v.check("i")
    assert v.done() and v.accuracy() == 100.0

def test_validator_no_input_after_done():
    v = Validator("a"); v.check("a")
    ok, _ = v.check("a")
    assert not ok


# ── Storage ───────────────────────────────────────────────────────────────────

@pytest.fixture
def sto(tmp_path):
    return Storage(file=str(tmp_path / "r.json"))

def _rec(**kw):
    return {'cpm': 100, 'wpm': 20, 'accuracy': 90.0,
            'total': 50, 'correct': 45, 'errors': 5, 'time': 15.0, **kw}

def test_storage_empty(sto):
    assert sto.records == [] and sto.best() is None

def test_storage_add_and_sort(sto):
    sto.add(_rec(cpm=100)); sto.add(_rec(cpm=300))
    assert sto.records[0]['cpm'] == 300

def test_storage_max_20(sto):
    for i in range(25): sto.add(_rec(cpm=i))
    assert len(sto.records) <= 20

def test_storage_persists(tmp_path):
    path = str(tmp_path / "r.json")
    s = Storage(file=path); s.add(_rec(cpm=200))
    assert Storage(file=path).records[0]['cpm'] == 200

def test_storage_clear(sto):
    sto.add(_rec()); sto.clear()
    assert sto.records == []

def test_storage_legacy_keys(tmp_path):
    path = tmp_path / "r.json"
    path.write_text(json.dumps([{'speed_cpm': 150, 'speed_wpm': 30,
        'accuracy': 92.0, 'total_keystrokes': 75, 'correct_keystrokes': 69,
        'time_seconds': 20.0, 'date': '2024-01-01 12:00'}]), encoding='utf-8')
    assert Storage(file=str(path)).records[0]['cpm'] == 150


# ── TextManager ───────────────────────────────────────────────────────────────

def test_builtin_texts_nonempty():
    texts = BuiltInTexts().get_texts()
    assert len(texts) > 0 and all(isinstance(t, str) and t for t in texts)

def test_textmanager_get_text():
    text = TextManager().get_text(source_key='builtin', size_key='S')
    assert isinstance(text, str) and len(text) > 0

def test_textmanager_size_limit():
    tm = TextManager()
    for _ in range(5):
        text = tm.get_text(source_key='builtin', size_key='S')
        assert len(text) <= TEXT_SIZES['S']['max'] * 1.35

def test_textmanager_bad_source_fallback():
    text = TextManager().get_text(source_key='__none__', size_key='S')
    assert isinstance(text, str) and len(text) > 0

def test_textmanager_add_book(tmp_path):
    path = tmp_path / "book.txt"
    path.write_text("This is a long enough sentence for the book. " * 10, encoding='utf-8')
    tm = TextManager()
    assert tm.add_book(str(path))
    assert any(k.startswith('book_') for k in tm.source_names())

def test_textmanager_add_book_missing(tmp_path):
    assert not TextManager().add_book(str(tmp_path / "missing.txt"))


# ── Интеграция ────────────────────────────────────────────────────────────────

def test_full_session():
    text = "hello world"
    val = Validator(text); ana = Analyzer(); ana.start()
    for ch in text:
        ok, _ = val.check(ch); ana.tap(ok)
    ana.stop()
    assert val.done() and ana.accuracy() == 100.0 and ana.total == len(text)

def test_session_with_errors():
    val = Validator("abc"); ana = Analyzer(); ana.start()
    val.check("a"); ana.tap(True)
    val.check("x"); ana.tap(False)
    val.check("b"); ana.tap(True)
    val.check("c"); ana.tap(True)
    assert len(val.errors) == 1 and ana.correct == 3 and ana.total == 4

def test_session_saves_to_storage(tmp_path):
    val = Validator("hi"); ana = Analyzer(); ana.start()
    for ch in "hi":
        ok, _ = val.check(ch); ana.tap(ok)
    ana.stop()
    stats = {**ana.stats(), 'errors': len(val.errors)}
    sto = Storage(file=str(tmp_path / "r.json")); sto.add(stats)
    assert sto.records[0]['accuracy'] == 100.0
