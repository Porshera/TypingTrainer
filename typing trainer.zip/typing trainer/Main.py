"""Тренажер слепой печати – главный модуль"""
import tkinter as tk
from tkinter import filedialog, messagebox
from text_manager import TextManager
from validator import Validator
from analyzer import Analyzer
from storage import Storage
from gui import GUI, ResultDialog, Leaderboard

class App:
    def __init__(self, root):
        self.root = root
        self.tm = TextManager()
        self.val: Validator = None
        self.ana = Analyzer()
        self.sto = Storage()
        self.running = False
        self.timer = None
        self._current_source = 'builtin'
        self._current_size   = 'M'
        
        self.gui = GUI(root)
        self.gui.set_commands(
            start=self.toggle,
            new_text=self.new_ex,
            leaderboard=self.show_lead,
            book_cmd=self.load_book,
            source_change=self._on_source_change,
        )
        self.gui.bind_input(self.key)
        
        # Горячие клавиши
        root.bind('<Control-o>', lambda e: self.load_book())
        root.bind('<Control-n>', lambda e: self.new_ex())
        root.bind('<Escape>',    lambda e: self.pause() if self.running else None)
        
        # Заполнить список источников и загрузить первый текст
        self._refresh_sources()
        self.new_ex()
    
    # ── Источники ─────────────────────────────────────────────────────────────
    def _refresh_sources(self):
        names = self.tm.source_names()
        self.gui.set_sources(names)
    
    def _on_source_change(self):
        """Смена источника или размера — загрузить новый текст"""
        self.new_ex()
    
    # ── Загрузка книги ────────────────────────────────────────────────────────
    def load_book(self):
        path = filedialog.askopenfilename(
            title="Выберите книгу (.txt)",
            filetypes=[("Текстовые файлы", "*.txt"), ("Все файлы", "*.*")]
        )
        if not path:
            return
        ok = self.tm.add_book(path)
        if ok:
            self._refresh_sources()
            # Переключиться на только что загруженную книгу
            names = self.tm.source_names()
            last_key = list(names.keys())[-1]
            self.gui.source_panel.set_sources(names, last_key)
            self.new_ex()
            messagebox.showinfo("📖 Книга загружена", "Книга добавлена в список источников.")
        else:
            messagebox.showwarning("Ошибка", "Не удалось загрузить книгу.\n"
                                             "Убедитесь, что файл в кодировке UTF-8.")
    
    # ── Обработка клавиш ──────────────────────────────────────────────────────
    def key(self, e):
        # Автостарт при первом нажатии
        if not self.running and self.val and not self.val.done():
            ignored = {'Shift_L', 'Shift_R', 'Control_L', 'Control_R', 'Alt_L', 'Alt_R',
                       'Tab', 'Caps_Lock', 'Escape', 'Left', 'Right', 'Up', 'Down',
                       'Home', 'End', 'Delete', 'Insert', 'F1', 'F2', 'F3', 'F4',
                       'F5', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12'}
            if e.keysym not in ignored and e.char and len(e.char) > 0:
                self.start(silent=True)
                # Продолжаем обработку символа ниже
            else:
                return "break"
        
        if not self.running or not self.val:
            return "break"
        
        if e.keysym in ('Shift_L', 'Shift_R', 'Control_L', 'Control_R', 'Alt_L', 'Alt_R',
                        'Tab', 'Caps_Lock', 'Escape', 'Left', 'Right', 'Up', 'Down',
                        'Home', 'End', 'Delete', 'Insert'):
            return
        if e.keysym == 'BackSpace':
            return "break"
        
        if e.char and len(e.char) > 0:
            ok, _ = self.val.check(e.char)
            self.ana.tap(ok)
            self.gui.work.show(self.val.text, self.val.status, self.val.pos, self.val.done())
            self.gui.clear_input()
            if self.val.done():
                self.finish()
        return "break"
    
    # ── Таймер статистики ─────────────────────────────────────────────────────
    def update_stats(self):
        if self.running and self.ana.start_time:
            errors = len(self.val.errors) if self.val else 0
            self.gui.stats.update(
                time=f"{self.ana.elapsed()} с",
                speed=f"{self.ana.cpm()} зн/мин",
                wpm=f"{self.ana.wpm()} сл/мин",
                errors=str(errors),
                accuracy=f"{self.ana.accuracy()}%"
            )
    
    def tick(self):
        if self.running:
            self.update_stats()
            self.timer = self.root.after(100, self.tick)
    
    # ── Управление упражнением ────────────────────────────────────────────────
    def toggle(self):
        if not self.running:
            self.start()
        else:
            self.pause()
    
    def start(self, silent: bool = False):
        if not self.val:
            self.new_ex()
        self.running = True
        self.ana.start()
        self.gui.set_running(True)
        self.gui.enable_input()
        self.tick()
    
    def pause(self):
        self.running = False
        self.ana.stop()
        self.gui.set_running(False)
        self.gui.disable_input()
        if self.timer:
            self.root.after_cancel(self.timer)
            self.timer = None
    
    def new_ex(self):
        if self.running:
            self.pause()
        
        src_key  = self.gui.get_source_key()
        size_key = self.gui.get_size_key()
        
        text = self.tm.get_text(source_key=src_key, size_key=size_key)
        self.val = Validator(text)
        self.ana = Analyzer()
        self.running = False
        self.gui.set_running(False)
        self.gui.disable_input()
        self.gui.stats.reset()
        self.gui.work.show(self.val.text, self.val.status, self.val.pos, self.val.done())
        
        # Показать кол-во символов в строке подсказки
        char_count = len(text)
        self.root.title(f"⌨ Тренажер слепой печати  •  {char_count} символов  •  {size_key}")
    
    def finish(self):
        self.running = False
        self.ana.stop()
        self.gui.set_running(False)
        self.gui.disable_input()
        if self.timer:
            self.root.after_cancel(self.timer)
            self.timer = None
        
        stats = self.ana.stats()
        stats['errors'] = len(self.val.errors) if self.val else 0
        self.sto.add(stats)
        
        ResultDialog(self.root, stats, self.new_ex, self.show_lead,
                     font_size=self.gui.current_font_size)
    
    def show_lead(self):
        Leaderboard(self.root, self.sto.top(),
                    font_size=self.gui.current_font_size)


if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("960x640")
    App(root)
    root.mainloop()
