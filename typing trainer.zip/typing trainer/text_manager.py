"""Менеджер текстов – загрузка из открытых источников, генерация, книги пользователя"""
import random, json, os, re, threading
from abc import ABC, abstractmethod
from typing import List, Dict, Optional
try:
    import urllib.request
    HAS_NET = True
except ImportError:
    HAS_NET = False

# ── Размеры текста ────────────────────────────────────────────────────────────
TEXT_SIZES = {
    'S':  {'label': 'S - Короткий',  'min': 60,  'max': 120},
    'M':  {'label': 'M - Средний',   'min': 150, 'max': 280},
    'L':  {'label': 'L - Длинный',   'min': 300, 'max': 500},
    'XL': {'label': 'XL - Очень длинный', 'min': 550, 'max': 900},
}
DEFAULT_SIZE = 'M'

# ── Базовый класс источника ───────────────────────────────────────────────────
class TextSource(ABC):
    name: str = "Источник"
    lang: str = "en"   # "en" | "ru"
    
    @abstractmethod
    def get_texts(self) -> List[str]: pass
    
    def available(self) -> bool: return True


# ── Встроенные тексты ─────────────────────────────────────────────────────────
class BuiltInTexts(TextSource):
    name = "Встроенные"
    lang = "en"
    TEXTS = [
        "The quick brown fox jumps over the lazy dog. Pack my box with five dozen liquor jugs.",
        "Programming is the art of telling another human what one wants the computer to do. It requires patience, creativity, and attention to detail.",
        "Practice makes perfect. After a long time of practicing, our work will become natural, skillful, swift, and steady. Consistency is the key.",
        "Python is a versatile language used for web development, data science, artificial intelligence, and scripting. It emphasizes readability.",
        "Touch typing is the ability to type without looking at the keyboard. With enough practice, your fingers will find every key automatically.",
        "Data structures and algorithms are the foundation of computer science. Understanding them leads to writing efficient and elegant code.",
        "The best way to learn programming is to write programs. Start small, build up complexity, and never stop experimenting with ideas.",
        "Version control systems like Git help developers collaborate effectively. Every change is tracked, and mistakes can always be undone.",
        "Cloud computing provides on-demand access to a shared pool of configurable computing resources including networks, servers, and storage.",
        "Artificial intelligence and machine learning are transforming industries. From healthcare to finance, intelligent systems automate complex tasks.",
        "A good programmer writes code that humans can understand. Documentation, clean naming, and thoughtful structure make software maintainable.",
        "The internet has revolutionized communication worldwide. Information flows freely across borders, connecting billions of people every second.",
        "Cybersecurity is the practice of protecting systems, networks, and programs from digital attacks. Strong passwords and encryption are essential.",
        "Mobile applications have become essential tools in daily life. They simplify banking, navigation, communication, and entertainment.",
        "Open source software is built collaboratively by communities around the world. Anyone can contribute improvements and share the results freely.",
    ]
    def get_texts(self) -> List[str]: return self.TEXTS


# ── Тексты из JSON-файла ──────────────────────────────────────────────────────
class FileTexts(TextSource):
    name = "Файл texts.json"
    def __init__(self, path: str):
        self.path = path
    
    def get_texts(self) -> List[str]:
        if not os.path.exists(self.path): return []
        try:
            with open(self.path, 'r', encoding='utf-8') as f:
                if self.path.endswith('.json'):
                    data = json.load(f)
                    return data if isinstance(data, list) else data.get('texts', [])
                return [l.strip() for l in f if l.strip()]
        except: return []
    
    def available(self) -> bool: return os.path.exists(self.path)


# ── Книга пользователя ────────────────────────────────────────────────────────
class BookTexts(TextSource):
    def __init__(self, path: str):
        self.path = path
        self.name = f"📖 {os.path.basename(path)}"
        self.sentences: List[str] = []
        self._load()
    
    def _load(self):
        if not os.path.exists(self.path): return
        try:
            with open(self.path, 'r', encoding='utf-8') as f:
                text = f.read()
            raw = re.split(r'(?<=[.!?])\s+', text)
            self.sentences = [s.strip() for s in raw if 30 < len(s.strip()) < 600]
        except Exception as e:
            print(f"Ошибка загрузки книги: {e}")
    
    def get_texts(self) -> List[str]: return self.sentences
    def available(self) -> bool: return len(self.sentences) > 0


# ── Wikipedia (случайная статья, первый абзац) ────────────────────────────────
class WikipediaTexts(TextSource):
    name = "🌐 Wikipedia"
    lang = "en"
    _cache: List[str] = []
    _lock = threading.Lock()
    
    def _fetch_random(self) -> Optional[str]:
        if not HAS_NET: return None
        try:
            url = "https://en.wikipedia.org/api/rest_v1/page/random/summary"
            req = urllib.request.Request(url, headers={'User-Agent': 'TypingTrainer/1.0'})
            with urllib.request.urlopen(req, timeout=6) as r:
                data = json.loads(r.read().decode())
                extract = data.get('extract', '')
                # Берём первые предложения, не больше 900 символов
                sentences = re.split(r'(?<=[.!?])\s+', extract)
                result = []
                total = 0
                for s in sentences:
                    s = s.strip()
                    if not s or len(s) < 20: continue
                    if total + len(s) > 900: break
                    result.append(s)
                    total += len(s) + 1
                if result:
                    return ' '.join(result)
        except: pass
        return None
    
    def get_texts(self) -> List[str]:
        with self._lock:
            if len(self._cache) < 3:
                for _ in range(3):
                    t = self._fetch_random()
                    if t: self._cache.append(t)
        return list(self._cache)
    
    def refresh(self):
        """Фоновое обновление кэша"""
        def _bg():
            fetched = []
            for _ in range(5):
                t = self._fetch_random()
                if t: fetched.append(t)
            with self._lock:
                WikipediaTexts._cache = fetched
        threading.Thread(target=_bg, daemon=True).start()


# ── Wikiquote (цитаты) ────────────────────────────────────────────────────────
class WikiquoteTexts(TextSource):
    name = "💬 Цитаты"
    lang = "en"
    _cache: List[str] = []
    
    FALLBACK_QUOTES = [
        "The only way to do great work is to love what you do. If you haven't found it yet, keep looking.",
        "In the middle of every difficulty lies opportunity. Success is not final, failure is not fatal: it is the courage to continue that counts.",
        "Imagination is more important than knowledge. Knowledge is limited, but imagination encircles the world and points to all there is still to discover.",
        "It does not matter how slowly you go as long as you do not stop. Our greatest glory is not in never falling, but in rising every time we fall.",
        "The future belongs to those who believe in the beauty of their dreams. Life is what happens when you are busy making other plans.",
        "You miss one hundred percent of the shots you do not take. The greatest risk is not taking any risk at all in a rapidly changing world.",
        "Whether you think you can or you think you cannot, you are right. Happiness depends upon ourselves, not upon the circumstances around us.",
        "The way to get started is to quit talking and begin doing. Success usually comes to those who are too busy to be looking for it.",
        "Innovation distinguishes between a leader and a follower. Stay hungry, stay foolish, and never lose your beginner's mind and curiosity.",
        "It is during our darkest moments that we must focus to see the light. The pessimist sees difficulty in every opportunity; the optimist sees opportunity in every difficulty.",
        "The secret of getting ahead is getting started. The secret of getting started is breaking your complex overwhelming tasks into small manageable ones.",
        "Tell me and I forget. Teach me and I remember. Involve me and I learn. Real knowledge is knowing the extent of one's ignorance.",
    ]
    
    def get_texts(self) -> List[str]:
        if self._cache:
            return self._cache
        # Попытка получить из API
        if HAS_NET:
            try:
                url = "https://api.quotable.io/quotes/random?limit=20&minLength=80&maxLength=300"
                req = urllib.request.Request(url, headers={'User-Agent': 'TypingTrainer/1.0'})
                with urllib.request.urlopen(req, timeout=5) as r:
                    data = json.loads(r.read().decode())
                    quotes = [f"{q['content']} — {q['author']}" for q in data if 'content' in q]
                    if quotes:
                        WikiquoteTexts._cache = quotes
                        return quotes
            except: pass
        WikiquoteTexts._cache = self.FALLBACK_QUOTES
        return self.FALLBACK_QUOTES


# ── Project Gutenberg (классика) ──────────────────────────────────────────────
class GutenbergTexts(TextSource):
    name = "📚 Классика"
    lang = "en"
    # Список текстов из открытого доступа — короткие отрывки
    CLASSICS = [
        "It was the best of times, it was the worst of times, it was the age of wisdom, it was the age of foolishness, it was the epoch of belief, it was the epoch of incredulity.",
        "Call me Ishmael. Some years ago never mind how long precisely having little or no money in my purse and nothing particular to interest me on shore, I thought I would sail about a little.",
        "It is a truth universally acknowledged, that a single man in possession of a good fortune, must be in want of a wife. However little known the feelings or views of such a man may be.",
        "All happy families are alike; each unhappy family is unhappy in its own way. Everything was in confusion in the Oblonskys' house.",
        "In my younger and more vulnerable years my father gave me some advice that I have been turning over in my mind ever since. Whenever you feel like criticizing anyone, just remember that all the people in this world haven't had the advantages that you've had.",
        "Last night I dreamt I went to Manderley again. It seemed to me I stood by the iron gate leading to the drive, and for a while I could not enter for the way was barred to me.",
        "The man in black fled across the desert, and the gunslinger followed. The desert was the apotheosis of all deserts, huge, standing to the sky for what looked like eternity in all directions.",
        "Happy families are all alike; every unhappy family is unhappy in its own way. Stately, plump Buck Mulligan came from the stairhead, bearing a bowl of lather on which a mirror and a razor lay crossed.",
        "Once upon a time and a very good time it was there was a moocow coming down along the road and this moocow that was coming down along the road met a nicens little boy named baby tuckoo.",
        "It was a bright cold day in April, and the clocks were striking thirteen. Winston Smith, his chin nuzzled into his breast in an effort to escape the vile wind, slipped quickly through the glass doors.",
        "We were somewhere around Barstow on the edge of the desert when the drugs began to take hold. I remember saying something like I feel a bit lightheaded; maybe you should drive.",
        "The sky above the port was the color of television, tuned to a dead channel. The case had been hauled before three separate grand juries before it finally collapsed.",
        "Midway upon the journey of our life I found myself within a forest dark, for the straightforward pathway had been lost. How hard a thing it is to say what was that savage forest.",
        "Two households, both alike in dignity, in fair Verona, where we lay our scene, from ancient grudge break to new mutiny, where civil blood makes civil hands unclean.",
        "To be, or not to be, that is the question: whether tis nobler in the mind to suffer the slings and arrows of outrageous fortune, or to take arms against a sea of troubles.",
    ]
    
    def get_texts(self) -> List[str]: return self.CLASSICS


# ── ИИ-генерация через простые n-граммы (без внешних зависимостей) ────────────
class GenerativeTexts(TextSource):
    name = "🤖 Генерация"
    lang = "en"
    
    TEMPLATES = [
        "The {adj} {noun} {verb} {adv} through the {adj2} {noun2} while the {noun3} {verb2} in the {adj3} {noun4}.",
        "In a world where {noun} meets {noun2}, the {adj} programmer must {verb} every {noun3} with {adj2} precision.",
        "Every {adj} {noun} begins with a single {noun2}. The key to {noun3} is to {verb} {adv} and {verb2} with purpose.",
        "Scientists discovered that {adj} {noun} can {verb} the {noun2} when exposed to {adj2} {noun3} for extended periods.",
        "The {adj} city of {noun} was known for its {adj2} {noun2} and the way its citizens would {verb} every {noun3}.",
    ]
    WORDS = {
        'adj':  ['brilliant', 'complex', 'dynamic', 'elegant', 'focused', 'graceful', 'humble', 'intricate', 'logical', 'modern'],
        'adj2': ['ancient', 'bold', 'careful', 'deep', 'efficient', 'fluid', 'great', 'honest', 'ideal', 'just'],
        'adj3': ['abstract', 'basic', 'classic', 'diverse', 'exact', 'fresh', 'genuine', 'hard', 'inner', 'keen'],
        'noun': ['algorithm', 'browser', 'compiler', 'database', 'editor', 'framework', 'gateway', 'handler', 'interface', 'journal'],
        'noun2':['kernel', 'library', 'module', 'network', 'object', 'parser', 'query', 'runtime', 'system', 'template'],
        'noun3':['user', 'value', 'window', 'example', 'year', 'zero', 'method', 'function', 'class', 'type'],
        'noun4':['pipeline', 'repository', 'service', 'thread', 'union', 'variable', 'workflow', 'context', 'domain', 'engine'],
        'verb': ['analyze', 'build', 'create', 'define', 'execute', 'format', 'generate', 'handle', 'implement', 'justify'],
        'verb2':['keep', 'learn', 'manage', 'navigate', 'optimize', 'process', 'question', 'render', 'search', 'transform'],
        'adv':  ['carefully', 'directly', 'efficiently', 'fluently', 'gracefully', 'honestly', 'intuitively', 'logically', 'naturally', 'optimally'],
    }
    
    def _make_sentence(self) -> str:
        tpl = random.choice(self.TEMPLATES)
        for key, words in self.WORDS.items():
            tpl = tpl.replace('{' + key + '}', random.choice(words))
        return tpl
    
    def get_texts(self) -> List[str]:
        return [' '.join(self._make_sentence() for _ in range(random.randint(2, 4)))
                for _ in range(10)]


# ── Русские встроенные тексты ─────────────────────────────────────────────────
class RussianTexts(TextSource):
    name = "🇷🇺 Встроенные"
    lang = "ru"
    TEXTS = [
        "Программирование - это искусство решения задач с помощью логики и творчества. Хороший код читается как хорошая книга: он понятен, структурирован и элегантен.",
        "Быстрый набор текста - полезный навык в современном мире. Регулярные тренировки помогут вашим пальцам запомнить расположение клавиш без лишних усилий.",
        "Питон - один из самых популярных языков программирования. Его простой синтаксис позволяет сосредоточиться на решении задачи, а не на деталях языка.",
        "Машинное обучение изменяет подход к разработке программного обеспечения. Алгоритмы способны обнаруживать закономерности в огромных массивах данных.",
        "Интернет соединил миллиарды людей по всему миру. Обмен знаниями и идеями никогда ещё не был таким быстрым и доступным для каждого.",
        "Искусственный интеллект проникает во все сферы жизни: медицину, образование, транспорт и промышленность. Это меняет привычные способы работы и общения.",
        "Структуры данных и алгоритмы - основа информатики. Умение выбрать подходящую структуру данных часто определяет эффективность всей программы.",
        "Системы контроля версий позволяют командам работать над кодом совместно. Каждое изменение фиксируется, и любую ошибку можно быстро отменить.",
        "Облачные вычисления предоставляют доступ к мощным ресурсам через интернет. Разработчики могут масштабировать приложения без покупки собственных серверов.",
        "Кибербезопасность защищает системы и данные от цифровых угроз. Надёжные пароли, шифрование и регулярные обновления - основа защиты информации.",
        "Мобильные приложения стали неотъемлемой частью повседневной жизни. Они упрощают банковские операции, навигацию, общение и развлечения.",
        "Открытый исходный код объединяет разработчиков со всего мира. Любой желающий может изучить код, предложить улучшения и поделиться результатом.",
        "Наука о данных помогает извлекать ценные знания из больших объёмов информации. Визуализация данных делает сложные закономерности понятными и наглядными.",
        "Разработка программного обеспечения требует как технических, так и творческих навыков. Умение работать в команде и общаться не менее важно, чем знание языков.",
        "Хороший программист пишет код, понятный другим людям. Чистые имена переменных, документация и продуманная структура делают программу удобной в поддержке.",
        "Алгоритм - это последовательность чётких инструкций для решения задачи. Умение разбить сложную проблему на простые шаги - ключевой навык разработчика.",
        "Тестирование - важная часть разработки качественного программного обеспечения. Автоматические тесты помогают обнаружить ошибки до того, как они попадут к пользователям.",
        "Рефакторинг - процесс улучшения кода без изменения его поведения. Регулярное очищение и упрощение кода снижает технический долг и облегчает дальнейшую разработку.",
        "Паттерны проектирования - проверенные решения для типичных задач разработки. Их знание помогает создавать гибкие и расширяемые программные системы.",
        "Слепой метод набора текста позволяет печатать быстро и без усталости. Главное - правильная постановка пальцев и терпеливая ежедневная практика.",
    ]
    def get_texts(self) -> List[str]: return self.TEXTS


# ── Русская Википедия ─────────────────────────────────────────────────────────
class WikipediaRuTexts(TextSource):
    name = "🇷🇺 Википедия"
    lang = "ru"
    _cache: List[str] = []
    _lock = threading.Lock()

    def _fetch_random(self) -> Optional[str]:
        if not HAS_NET: return None
        try:
            url = "https://ru.wikipedia.org/api/rest_v1/page/random/summary"
            req = urllib.request.Request(url, headers={'User-Agent': 'TypingTrainer/1.0'})
            with urllib.request.urlopen(req, timeout=6) as r:
                data = json.loads(r.read().decode())
                extract = data.get('extract', '')
                sentences = re.split(r'(?<=[.!?])\s+', extract)
                result = []
                total = 0
                for s in sentences:
                    s = s.strip()
                    if not s or len(s) < 20: continue
                    if total + len(s) > 900: break
                    result.append(s)
                    total += len(s) + 1
                if result:
                    return ' '.join(result)
        except: pass
        return None

    def get_texts(self) -> List[str]:
        with self._lock:
            if len(self._cache) < 3:
                for _ in range(3):
                    t = self._fetch_random()
                    if t: self._cache.append(t)
        return list(self._cache) or RussianTexts.TEXTS

    def refresh(self):
        def _bg():
            fetched = []
            for _ in range(5):
                t = self._fetch_random()
                if t: fetched.append(t)
            with self._lock:
                WikipediaRuTexts._cache = fetched
        threading.Thread(target=_bg, daemon=True).start()


# ── Русские цитаты ────────────────────────────────────────────────────────────
class RussianQuoteTexts(TextSource):
    name = "🇷🇺 Цитаты"
    lang = "ru"
    QUOTES = [
        "Нет ничего невозможного для человека с интеллектом. Главное - желать и действовать.",
        "Счастье - это когда тебя понимают. Великое счастье - это когда тебя понимают, даже когда ты молчишь.",
        "Учитесь так, словно вы постоянно ощущаете нехватку своих знаний, и так, словно вы постоянно боитесь растерять свои знания.",
        "Жить - значит мыслить. Человек, который перестаёт думать, перестаёт жить в полном смысле этого слова.",
        "Не бойся медленно идти вперёд, бойся стоять на месте. Маленькие шаги каждый день складываются в большой путь.",
        "Труд освобождает от трёх великих зол: скуки, порока и нужды. Деятельный человек всегда счастливее праздного.",
        "Знание - сила. Тот, кто владеет информацией, владеет миром и способен менять его по своему усмотрению.",
        "Самое трудное - познать самого себя, самое лёгкое - давать советы другим людям.",
        "Книга - это зеркало. Если в неё смотрит обезьяна, из неё не выглянет апостол.",
        "Самый верный признак истины - это простота и ясность. Ложь всегда сложна, вычурна и многословна.",
        "Человек рождён для счастья, как птица для полёта. Несчастье приходит лишь от незнания, лени или слабоволия.",
        "Нельзя дважды войти в одну реку. Всё течёт, всё изменяется - и это единственная настоящая константа бытия.",
        "Красота спасёт мир. Любовь и красота - вот две главные силы, которые движут человечество вперёд.",
        "Все счастливые семьи похожи друг на друга, каждая несчастливая семья несчастлива по-своему.",
        "Бороться и искать, найти и не сдаваться - вот девиз настоящего человека на протяжении всей его жизни.",
    ]
    def get_texts(self) -> List[str]: return self.QUOTES


# ── Менеджер ──────────────────────────────────────────────────────────────────
class TextManager:
    def __init__(self):
        self._books: List[BookTexts] = []
        
        # Постоянные встроенные источники
        self._builtin    = BuiltInTexts()
        self._russian    = RussianTexts()
        self._wiki_ru    = WikipediaRuTexts()
        self._quotes_ru  = RussianQuoteTexts()
        self._classics   = GutenbergTexts()
        self._quotes     = WikiquoteTexts()
        self._wiki       = WikipediaTexts()
        self._generative = GenerativeTexts()
        self._file_src   = FileTexts("texts.json") if os.path.exists("texts.json") else None
        
        # Начать фоновую загрузку Wikipedia
        self._wiki.refresh()
        self._wiki_ru.refresh()
    
    # ── Публичные источники (для UI) ─────────────────────────────────────────
    @property
    def sources(self) -> Dict[str, TextSource]:
        d: Dict[str, TextSource] = {
            'builtin':    self._builtin,
            'classics':   self._classics,
            'quotes':     self._quotes,
            'wiki':       self._wiki,
            'generated':  self._generative,
            'russian':    self._russian,
            'wiki_ru':    self._wiki_ru,
            'quotes_ru':  self._quotes_ru,
        }
        if self._file_src and self._file_src.available():
            d['file'] = self._file_src
        for i, b in enumerate(self._books):
            d[f'book_{i}'] = b
        return d
    
    def source_names(self) -> Dict[str, str]:
        return {k: v.name for k, v in self.sources.items()}
    
    # ── Книги пользователя ───────────────────────────────────────────────────
    def add_book(self, path: str) -> bool:
        if not os.path.exists(path): return False
        book = BookTexts(path)
        if not book.sentences: return False
        self._books.append(book)
        print(f"📖 Книга: {book.name} ({len(book.sentences)} предложений)")
        return True
    
    # ── Получение текста ─────────────────────────────────────────────────────
    def get_text(self, source_key: str = 'builtin', size_key: str = 'M') -> str:
        src = self.sources.get(source_key, self._builtin)
        size = TEXT_SIZES.get(size_key, TEXT_SIZES['M'])
        target_len = random.randint(size['min'], size['max'])
        
        try:
            texts = src.get_texts()
        except:
            texts = []
        
        if not texts:
            texts = self._builtin.get_texts()
        
        # Для Wikipedia обновляем кэш в фоне
        if source_key == 'wiki':
            self._wiki.refresh()
        
        return self._compose(texts, target_len)
    
    def _compose(self, texts: List[str], target_len: int) -> str:
        """Составить текст нужной длины из доступных предложений"""
        random.shuffle(texts)
        
        # Сначала пробуем найти один текст нужной длины
        good = [t for t in texts if target_len * 0.7 <= len(t) <= target_len * 1.3]
        if good:
            return random.choice(good)
        
        # Составляем из предложений
        sentences: List[str] = []
        for text in texts:
            parts = re.split(r'(?<=[.!?])\s+', text)
            sentences.extend([p.strip() for p in parts if len(p.strip()) > 15])
        
        if not sentences:
            return random.choice(texts)[:target_len]
        
        random.shuffle(sentences)
        result = []
        total = 0
        for s in sentences:
            if total + len(s) + 1 > target_len * 1.15:
                break
            result.append(s)
            total += len(s) + 1
            if total >= target_len * 0.85:
                break
        
        if not result:
            result = [sentences[0]]
        
        composed = ' '.join(result)
        return composed[:int(target_len * 1.2)]