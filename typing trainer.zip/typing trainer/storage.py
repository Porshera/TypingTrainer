"""Хранилище – сохранение рекордов в локальное хранилище для ведения таблицы лидеров"""
import json, os
from datetime import datetime
from typing import List, Dict, Optional

class Storage:
    def __init__(self, file: str = "records.json"):
        self.file = file
        self.records: List[Dict] = self.load()
    
    def load(self) -> List[Dict]:
        try:
            if os.path.exists(self.file):
                with open(self.file, 'r', encoding='utf-8') as f:
                    records = json.load(f)
                    # Проверяем и исправляем ключи
                    for r in records:
                        if 'speed_cpm' in r and 'cpm' not in r:
                            r['cpm'] = r['speed_cpm']
                        if 'speed_wpm' in r and 'wpm' not in r:
                            r['wpm'] = r['speed_wpm']
                        if 'total_keystrokes' in r and 'total' not in r:
                            r['total'] = r['total_keystrokes']
                        if 'correct_keystrokes' in r and 'correct' not in r:
                            r['correct'] = r['correct_keystrokes']
                        if 'time_seconds' in r and 'time' not in r:
                            r['time'] = r['time_seconds']
                    return records
        except: pass
        return []
    
    def save(self):
        try:
            with open(self.file, 'w', encoding='utf-8') as f:
                json.dump(self.records, f, ensure_ascii=False, indent=2)
        except: pass
    
    def add(self, stats: Dict):
        record = {
            'date': datetime.now().strftime("%Y-%m-%d %H:%M"),
            'cpm': stats.get('cpm', 0),
            'wpm': stats.get('wpm', 0),
            'accuracy': stats.get('accuracy', 0),
            'total': stats.get('total', 0),
            'correct': stats.get('correct', 0),
            'errors': stats.get('errors', 0),
            'time': stats.get('time', 0)
        }
        self.records.append(record)
        # Безопасная сортировка с проверкой наличия ключей
        self.records.sort(key=lambda x: (x.get('cpm', 0), x.get('accuracy', 0)), reverse=True)
        self.records = self.records[:20]
        self.save()
    
    def top(self, n: int = 10) -> List[Dict]: 
        return self.records[:n]
    
    def best(self) -> Optional[Dict]: 
        return self.records[0] if self.records else None
    
    def clear(self):
        self.records = []
        self.save()