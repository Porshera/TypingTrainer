"""Анализатор – вычисление скорости (зн/мин) и точности (% верных нажатий)"""
from datetime import datetime
from typing import Dict

class Analyzer:
    def __init__(self):
        self.start_time = None
        self.end_time = None
        self.total = 0
        self.correct = 0
    
    def start(self):
        self.start_time = datetime.now()
        self.end_time = None
        self.total = 0
        self.correct = 0
    
    def stop(self): self.end_time = datetime.now()
    
    def tap(self, ok: bool):
        self.total += 1
        if ok: self.correct += 1
    
    def cpm(self) -> int:
        if not self.start_time or self.total == 0: return 0
        end = self.end_time or datetime.now()
        sec = (end - self.start_time).total_seconds()
        return int((self.total / sec) * 60) if sec > 0 else 0
    
    def wpm(self) -> int: return self.cpm() // 5
    
    def accuracy(self) -> float:
        return round((self.correct / self.total) * 100, 1) if self.total else 100.0
    
    def elapsed(self) -> float:
        if not self.start_time: return 0.0
        end = self.end_time or datetime.now()
        return round((end - self.start_time).total_seconds(), 1)
    
    def stats(self) -> Dict:
        return {
            'cpm': self.cpm(), 'wpm': self.wpm(), 'accuracy': self.accuracy(),
            'total': self.total, 'correct': self.correct, 'errors': self.total - self.correct,
            'time': self.elapsed()
        }