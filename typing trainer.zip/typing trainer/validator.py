"""Валидатор – посимвольное сравнение в реальном времени и выявление ошибок"""
from typing import List, Dict, Tuple

class Validator:
    def __init__(self, text: str):
        self.text = text.strip()
        self.pos = 0
        self.errors: List[Dict] = []
        self.typed = 0
        self.correct = 0
        self.status = ['pending'] * len(self.text)
    
    def check(self, char: str) -> Tuple[bool, str]:
        if self.pos >= len(self.text): return False, ""
        
        expected = self.text[self.pos]
        ok = (char == expected)
        self.typed += 1
        
        if ok:
            self.correct += 1
            self.status[self.pos] = 'correct'
            self.pos += 1
        else:
            self.status[self.pos] = 'incorrect'
            self.errors.append({'pos': self.pos, 'expected': expected, 'got': char})
        
        return ok, expected
    
    def accuracy(self) -> float:
        return round((self.correct / self.typed) * 100, 1) if self.typed else 100.0
    
    def done(self) -> bool: return self.pos >= len(self.text)
    
    def progress(self) -> Tuple[int, int]: return self.pos, len(self.text)