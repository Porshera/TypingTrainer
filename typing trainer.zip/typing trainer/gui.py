"""Интерфейс – рабочая область, панель статистики, выбор источника/размера, рекорды"""
import tkinter as tk
from tkinter import ttk
from typing import Dict, List, Callable, Optional


# ═══════════════════════════════════════════════════════════════════════════════
# Панель статистики
# ═══════════════════════════════════════════════════════════════════════════════
class StatsPanel:
    def __init__(self, parent):
        self.frame = tk.Frame(parent, bg='#252526', relief=tk.FLAT, bd=0)
        self._items = {}
        specs = [
            ('time',  '⏱', 'Время',    '0.0 с',     '#569cd6', tk.LEFT),
            ('speed', '⚡', 'Скорость', '0 зн/мин',  '#dcdcaa', tk.LEFT),
            ('wpm',   '📝', 'Слов/мин', '0 сл/мин',  '#ce9178', tk.LEFT),
            ('err',   '✗',  'Ошибки',   '0',          '#f44747', tk.LEFT),
            ('acc',   '✓',  'Точность', '100%',       '#4ec9b0', tk.RIGHT),
        ]
        for key, icon, label, default, color, side in specs:
            f = tk.Frame(self.frame, bg='#252526'); f.pack(side=side, padx=12, pady=6)
            tk.Label(f, text=f"{icon} {label}:", fg='#6a6a6a',
                    font=('Arial', 10), bg='#252526').pack(side=tk.LEFT)
            lbl = tk.Label(f, text=default, fg=color,
                          font=('Arial', 11, 'bold'), bg='#252526')
            lbl.pack(side=tk.LEFT, padx=4)
            self._items[key] = lbl

    def update(self, time=None, speed=None, wpm=None, errors=None, accuracy=None):
        if time     is not None: self._items['time'].config(text=time)
        if speed    is not None: self._items['speed'].config(text=speed)
        if wpm      is not None: self._items['wpm'].config(text=wpm)
        if errors   is not None: self._items['err'].config(text=errors)
        if accuracy is not None: self._items['acc'].config(text=accuracy)

    def reset(self):
        self.update("0.0 с", "0 зн/мин", "0 сл/мин", "0", "100%")

    def pack(self, **kw): self.frame.pack(**kw)


# ═══════════════════════════════════════════════════════════════════════════════
# Панель выбора источника и объёма
# ═══════════════════════════════════════════════════════════════════════════════
class SourcePanel:
    """Выбор источника текста и размера упражнения"""
    SIZE_OPTS = [
        ('S',  'S — Короткий',       '60–120 симв.'),
        ('M',  'M — Средний',        '150–280 симв.'),
        ('L',  'L — Длинный',        '300–500 симв.'),
        ('XL', 'XL — Очень длинный', '550–900 симв.'),
    ]

    def __init__(self, parent, on_change: Callable):
        self.on_change = on_change
        self._lang = 'en'          # текущий язык
        self._all_names: Dict[str, str] = {}   # все источники
        self.frame = tk.Frame(parent, bg='#1e1e1e')

        # ── Переключатель языка RU / EN ────────────────────────────────────
        lang_frame = tk.Frame(self.frame, bg='#1e1e1e')
        lang_frame.pack(side=tk.LEFT, padx=(0, 14))
        self._lang_btns: Dict[str, tk.Button] = {}
        for code, label in [('en', 'EN'), ('ru', 'RU')]:
            btn = tk.Button(lang_frame, text=label, font=('Arial', 10, 'bold'),
                            relief=tk.FLAT, padx=10, pady=4, cursor='hand2',
                            command=lambda c=code: self._set_lang(c))
            btn.pack(side=tk.LEFT, padx=1)
            self._lang_btns[code] = btn
        self._update_lang_buttons()
        
        # ── Размер текста ──────────────────────────────────────────────────
        sz_frame = tk.Frame(self.frame, bg='#1e1e1e')
        sz_frame.pack(side=tk.LEFT, padx=(0, 20))
        tk.Label(sz_frame, text="Объём:", fg='#6a6a6a',
                font=('Arial', 10), bg='#1e1e1e').pack(side=tk.LEFT, padx=(0, 6))
        
        self._size_var = tk.StringVar(value='M')
        self._size_btns: Dict[str, tk.Button] = {}
        for key, label, hint in self.SIZE_OPTS:
            btn = tk.Button(sz_frame, text=key, font=('Arial', 10, 'bold'),
                           relief=tk.FLAT, padx=10, pady=4,
                           cursor='hand2',
                           command=lambda k=key: self._set_size(k))
            btn.pack(side=tk.LEFT, padx=2)
            btn.bind('<Enter>', lambda e, b=btn, k=key: self._hover(b, k, True))
            btn.bind('<Leave>', lambda e, b=btn, k=key: self._hover(b, k, False))
            # Tooltip с кол-вом символов
            self._add_tooltip(btn, hint)
            self._size_btns[key] = btn
        
        # ── Источник ──────────────────────────────────────────────────────
        src_frame = tk.Frame(self.frame, bg='#1e1e1e')
        src_frame.pack(side=tk.LEFT, padx=(0, 10))
        tk.Label(src_frame, text="Источник:", fg='#6a6a6a',
                font=('Arial', 10), bg='#1e1e1e').pack(side=tk.LEFT, padx=(0, 6))
        
        self._src_var = tk.StringVar()
        self._src_combo = ttk.Combobox(src_frame, textvariable=self._src_var,
                                       state='readonly', width=22,
                                       font=('Arial', 10))
        self._src_combo.pack(side=tk.LEFT)
        self._src_combo.bind('<<ComboboxSelected>>', lambda e: self.on_change())
        
        # ── Кол-во символов (информация) ──────────────────────────────────
        self._char_lbl = tk.Label(self.frame, text="", fg='#4a4a4a',
                                  font=('Arial', 9, 'italic'), bg='#1e1e1e')
        self._char_lbl.pack(side=tk.LEFT, padx=8)
        
        self._update_size_buttons()

    # ── Tooltip ───────────────────────────────────────────────────────────────
    def _add_tooltip(self, widget: tk.Widget, text: str):
        tip = None
        def show(e):
            nonlocal tip
            tip = tk.Toplevel(widget)
            tip.wm_overrideredirect(True)
            tip.wm_geometry(f"+{e.x_root+10}+{e.y_root+20}")
            tk.Label(tip, text=text, bg='#3c3c3c', fg='#cccccc',
                    font=('Arial', 9), padx=6, pady=3).pack()
        def hide(e):
            nonlocal tip
            if tip: tip.destroy(); tip = None
        widget.bind('<Enter>', lambda e: (show(e),))
        widget.bind('<Leave>', lambda e: (hide(e),))

    def _hover(self, btn: tk.Button, key: str, enter: bool):
        current = self._size_var.get()
        if key == current: return
        btn.config(bg='#3c3c3c' if enter else '#2d2d2d')

    def _set_size(self, key: str):
        self._size_var.set(key)
        self._update_size_buttons()
        self.on_change()

    def _update_size_buttons(self):
        current = self._size_var.get()
        hints = {k: h for k, _, h in self.SIZE_OPTS}
        for key, btn in self._size_btns.items():
            if key == current:
                btn.config(bg='#0e639c', fg='white')
                self._char_lbl.config(text=f"({hints[key]})")
            else:
                btn.config(bg='#2d2d2d', fg='#858585')

    # ── Язык ──────────────────────────────────────────────────────────────────
    def _set_lang(self, lang: str):
        self._lang = lang
        self._update_lang_buttons()
        self._apply_lang_filter()
        self.on_change()

    def _update_lang_buttons(self):
        for code, btn in self._lang_btns.items():
            if code == self._lang:
                btn.config(bg='#0e639c', fg='white')
            else:
                btn.config(bg='#2d2d2d', fg='#858585')

    def _apply_lang_filter(self):
        ru_keys = {'russian', 'wiki_ru', 'quotes_ru'}
        if self._lang == 'ru':
            filtered = {k: v for k, v in self._all_names.items()
                        if k in ru_keys or k.startswith('book_')}
        else:
            filtered = {k: v for k, v in self._all_names.items()
                        if k not in ru_keys and not k.startswith('book_')}
            # книги показываем в обоих режимах
            books = {k: v for k, v in self._all_names.items() if k.startswith('book_')}
            filtered.update(books)
        self._src_keys = list(filtered.keys())
        self._src_combo['values'] = list(filtered.values())
        if self._src_keys:
            self._src_combo.current(0)

    def get_lang(self) -> str:
        return self._lang

    # ── Обновление списка источников ──────────────────────────────────────────
    def set_sources(self, names: Dict[str, str], current_key: str = 'builtin'):
        self._all_names = names
        self._apply_lang_filter()
        if current_key in self._src_keys:
            idx = self._src_keys.index(current_key)
            self._src_combo.current(idx)

    def get_source_key(self) -> str:
        idx = self._src_combo.current()
        if hasattr(self, '_src_keys') and 0 <= idx < len(self._src_keys):
            return self._src_keys[idx]
        return 'builtin'

    def get_size_key(self) -> str:
        return self._size_var.get()

    def pack(self, **kw): self.frame.pack(**kw)


# ═══════════════════════════════════════════════════════════════════════════════
# Рабочая область
# ═══════════════════════════════════════════════════════════════════════════════
class WorkArea:
    def __init__(self, parent, font_size: int = 14):
        self.font_size = font_size
        self.frame = tk.Frame(parent, bg='#1a1a1a', relief=tk.FLAT, bd=0)
        
        # Внешняя рамка с градиентным эффектом
        inner = tk.Frame(self.frame, bg='#1e1e1e',
                         highlightbackground='#333333', highlightthickness=1)
        inner.pack(fill=tk.BOTH, expand=True, padx=2, pady=2)
        
        self.text = tk.Text(inner, wrap=tk.WORD,
                           font=('Consolas', self.font_size),
                           bg='#1e1e1e', fg='#d4d4d4',
                           height=8, state=tk.DISABLED,
                           spacing1=4, spacing2=6, spacing3=6,
                           padx=20, pady=15,
                           cursor='arrow',
                           selectbackground='#1e1e1e',
                           insertbackground='#1e1e1e')
        self.text.pack(fill=tk.BOTH, expand=True)
        self._setup_tags()

    def _setup_tags(self):
        f = ('Consolas', self.font_size)
        fb = ('Consolas', self.font_size, 'bold')
        self.text.tag_config("correct",   foreground="#4ec9b0", font=f)
        self.text.tag_config("incorrect", foreground="#f44747",
                             background="#3d1515", font=f)
        self.text.tag_config("pending",   foreground="#555555", font=f)
        self.text.tag_config("cursor",    background="#264f78",
                             foreground="#ffffff", font=fb)

    def set_font_size(self, size: int):
        self.font_size = size
        self.text.config(font=('Consolas', size))
        self._setup_tags()
        # Пересчитать высоту
        lines = max(5, min(14, size // 2 + 3))
        self.text.config(height=lines)

    def show(self, target: str, statuses: List[str], pos: int, done: bool):
        self.text.config(state=tk.NORMAL)
        self.text.delete(1.0, tk.END)
        for i, (ch, st) in enumerate(zip(target, statuses)):
            if i == pos and not done:
                self.text.insert(tk.END, ch, 'cursor')
            elif st == 'correct':
                self.text.insert(tk.END, ch, 'correct')
            elif st == 'incorrect':
                self.text.insert(tk.END, ch, 'incorrect')
            else:
                self.text.insert(tk.END, ch, 'pending')
        # Показать прогресс внизу
        if target:
            pct = int((pos / len(target)) * 100)
            self.text.insert(tk.END, f"\n\n{'█' * (pct // 5)}{'░' * (20 - pct // 5)} {pct}%", 'pending')
        self.text.config(state=tk.DISABLED)
        self.text.see(tk.END)

    def pack(self, **kw): self.frame.pack(**kw)


# ═══════════════════════════════════════════════════════════════════════════════
# Модальное окно – Таблица рекордов
# ═══════════════════════════════════════════════════════════════════════════════
class Leaderboard:
    def __init__(self, root, records: List[Dict], font_size: int = 14):
        scale = max(0.8, min(1.5, font_size / 14))
        w, h = int(620 * scale), int(500 * scale)
        
        self.dlg = tk.Toplevel(root)
        self.dlg.title("🏆 Таблица лидеров")
        self.dlg.geometry(f"{w}x{h}")
        self.dlg.configure(bg='#1e1e1e')
        self.dlg.transient(root)
        self.dlg.grab_set()
        
        fs = int(font_size * 0.85)
        fh = int(font_size * 1.1)
        
        tk.Label(self.dlg, text="ТОП-10 РЕКОРДОВ",
                font=('Arial', fh, 'bold'), fg='#dcdcaa', bg='#1e1e1e').pack(pady=(20, 12))
        
        t = tk.Frame(self.dlg, bg='#252526', highlightbackground='#333', highlightthickness=1)
        t.pack(fill=tk.BOTH, padx=20, pady=8, expand=True)
        
        headers = ['#', 'Дата', 'Скорость', 'Сл/мин', 'Точность', 'Ошибки', 'Время']
        for j, h_text in enumerate(headers):
            tk.Label(t, text=h_text, font=('Arial', fs, 'bold'),
                    fg='#569cd6', bg='#252526', padx=8, pady=6).grid(row=0, column=j, sticky='w')
        
        if not records:
            tk.Label(t, text="Нет рекордов", font=('Arial', fs),
                    fg='#555555', bg='#252526').grid(row=1, column=0, columnspan=7, pady=40)
        else:
            for i, r in enumerate(records, 1):
                color = '#dcdcaa' if i == 1 else ('#cccccc' if i <= 3 else '#888888')
                medal = ['🥇', '🥈', '🥉']
                rank = medal[i-1] if i <= 3 else str(i)
                vals = [rank, r.get('date','?'), f"{r.get('cpm',0)} зн/мин",
                        f"{r.get('wpm',0)} сл/мин",
                        f"{r.get('accuracy',0)}%", str(r.get('errors',0)),
                        f"{r.get('time',0)} с"]
                for j, v in enumerate(vals):
                    tk.Label(t, text=v, font=('Arial', fs),
                            fg=color, bg='#252526', padx=8, pady=3
                            ).grid(row=i, column=j, sticky='w')
        
        tk.Button(self.dlg, text="Закрыть", bg='#3c3c3c', fg='#cccccc',
                 font=('Arial', fs), relief=tk.FLAT, padx=24, pady=7,
                 command=self.dlg.destroy).pack(pady=16)


# ═══════════════════════════════════════════════════════════════════════════════
# Модальное окно – Результаты
# ═══════════════════════════════════════════════════════════════════════════════
class ResultDialog:
    def __init__(self, root, stats: Dict, on_restart, on_leaderboard, font_size: int = 14):
        scale = max(0.8, min(1.5, font_size / 14))
        w, h = int(440 * scale), int(510 * scale)
        
        self.dlg = tk.Toplevel(root)
        self.dlg.title("🎉 Упражнение завершено!")
        self.dlg.geometry(f"{w}x{h}")
        self.dlg.configure(bg='#1e1e1e')
        self.dlg.transient(root)
        self.dlg.grab_set()
        
        fs  = int(font_size * 0.9)
        fsh = int(font_size * 1.2)
        
        tk.Label(self.dlg, text="Отличная работа!",
                font=('Arial', fsh, 'bold'), fg='#4ec9b0', bg='#1e1e1e').pack(pady=(20, 12))
        
        card = tk.Frame(self.dlg, bg='#252526',
                       highlightbackground='#333333', highlightthickness=1)
        card.pack(fill=tk.BOTH, padx=22, pady=8)
        
        rows = [
            ("⚡ Скорость",    f"{stats.get('cpm',0)} зн/мин",  '#dcdcaa'),
            ("📝 Слов/минуту", f"{stats.get('wpm',0)} сл/мин",  '#dcdcaa'),
            ("✓ Точность",     f"{stats.get('accuracy',0)}%",    '#4ec9b0'),
            ("⌨️ Нажатий",    str(stats.get('total',0)),         '#569cd6'),
            ("✔ Правильно",    str(stats.get('correct',0)),       '#4ec9b0'),
            ("✗ Ошибок",       str(stats.get('errors',0)),        '#f44747'),
            ("⏱ Время",        f"{stats.get('time',0)} с",       '#dcdcaa'),
            ("📊 Символов",    str(stats.get('total',0)),         '#858585'),
        ]
        for label, val, col in rows:
            r = tk.Frame(card, bg='#252526'); r.pack(fill=tk.X, padx=18, pady=4)
            tk.Label(r, text=label, fg=col, bg='#252526',
                    font=('Arial', fs)).pack(side=tk.LEFT)
            tk.Label(r, text=val, fg='#ffffff', bg='#252526',
                    font=('Arial', fs, 'bold')).pack(side=tk.RIGHT)
        
        btns = tk.Frame(self.dlg, bg='#1e1e1e'); btns.pack(pady=16)
        tk.Button(btns, text="🔄 Заново", font=('Arial', fs, 'bold'),
                 bg='#0e639c', fg='white', relief=tk.FLAT,
                 padx=18, pady=8, cursor='hand2',
                 command=lambda: [self.dlg.destroy(), on_restart()]).pack(side=tk.LEFT, padx=8)
        tk.Button(btns, text="🏆 Рекорды", font=('Arial', fs),
                 bg='#3c3c3c', fg='#dcdcaa', relief=tk.FLAT,
                 padx=18, pady=8, cursor='hand2',
                 command=lambda: [self.dlg.destroy(), on_leaderboard()]).pack(side=tk.LEFT)


# ═══════════════════════════════════════════════════════════════════════════════
# Диалог выбора шрифта
# ═══════════════════════════════════════════════════════════════════════════════
class FontDialog:
    def __init__(self, root, current_size: int, callback: Callable[[int], None]):
        scale = max(0.8, min(1.5, current_size / 14))
        w, h = int(320 * scale), int(220 * scale)
        
        self.dlg = tk.Toplevel(root)
        self.dlg.title("🔤 Размер шрифта")
        self.dlg.geometry(f"{w}x{h}")
        self.dlg.configure(bg='#1e1e1e')
        self.dlg.transient(root)
        self.dlg.grab_set()
        
        fs = int(current_size * 0.9)
        
        tk.Label(self.dlg, text="Размер шрифта рабочей области:",
                font=('Arial', fs), fg='#cccccc', bg='#1e1e1e').pack(pady=(24, 8))
        
        self.scale = tk.Scale(self.dlg, from_=10, to=28, orient=tk.HORIZONTAL,
                             bg='#252526', fg='white', length=240,
                             troughcolor='#3c3c3c', highlightthickness=0,
                             font=('Arial', fs - 1))
        self.scale.set(current_size)
        self.scale.pack(pady=6)
        
        self.preview = tk.Label(self.dlg, text="Aa Bb Cc 123",
                                font=('Consolas', current_size),
                                fg='#4ec9b0', bg='#1e1e1e')
        self.preview.pack(pady=8)
        self.scale.config(command=lambda v: self.preview.config(font=('Consolas', int(v))))
        
        tk.Button(self.dlg, text="Применить", font=('Arial', fs),
                 bg='#0e639c', fg='white', relief=tk.FLAT, padx=20, pady=6,
                 command=lambda: [callback(int(self.scale.get())), self.dlg.destroy()]).pack(pady=8)


# ═══════════════════════════════════════════════════════════════════════════════
# Главный интерфейс
# ═══════════════════════════════════════════════════════════════════════════════
class GUI:
    def __init__(self, root):
        self.root = root
        self.root.title("⌨ Тренажер слепой печати")
        self.root.configure(bg='#1a1a1a')
        self.root.minsize(820, 560)
        self.current_font_size = 14
        
        # Стиль для Combobox
        style = ttk.Style()
        style.theme_use('default')
        style.configure('TCombobox', fieldbackground='#2d2d2d',
                        background='#2d2d2d', foreground='#cccccc',
                        selectbackground='#0e639c', arrowcolor='#858585')
        style.map('TCombobox', fieldbackground=[('readonly', '#2d2d2d')],
                  foreground=[('readonly', '#cccccc')])
        
        main = tk.Frame(root, bg='#1a1a1a')
        main.pack(fill=tk.BOTH, expand=True, padx=18, pady=12)
        
        # ── Заголовок ─────────────────────────────────────────────────────
        hdr = tk.Frame(main, bg='#1a1a1a')
        hdr.pack(fill=tk.X, pady=(0, 10))
        tk.Label(hdr, text="⌨", font=('Arial', 26), fg='#4ec9b0', bg='#1a1a1a').pack(side=tk.LEFT)
        tk.Label(hdr, text="ТРЕНАЖЕР СЛЕПОЙ ПЕЧАТИ",
                font=('Arial', 18, 'bold'), fg='#4ec9b0', bg='#1a1a1a').pack(side=tk.LEFT, padx=8)
        
        # ── Статистика ────────────────────────────────────────────────────
        self.stats = StatsPanel(main)
        self.stats.pack(fill=tk.X, pady=(0, 8))
        
        # ── Рабочая область ───────────────────────────────────────────────
        self.work = WorkArea(main, self.current_font_size)
        self.work.pack(fill=tk.BOTH, expand=True, pady=(0, 4))
        
        # ── Панель выбора источника/размера ───────────────────────────────
        self.source_panel = SourcePanel(main, on_change=self._on_source_change)
        self.source_panel.pack(fill=tk.X, pady=(0, 8))
        
        # ── Скрытый Entry для перехвата нажатий клавиш ───────────────────
        # (невидим, но всегда в фокусе во время упражнения)
        self._hidden_entry = tk.Entry(main, width=1, bg='#1a1a1a', fg='#1a1a1a',
                                      relief=tk.FLAT, insertbackground='#1a1a1a',
                                      highlightthickness=0, bd=0)
        self._hidden_entry.place(x=0, y=0, width=0, height=0)

        # ── Кнопки управления ─────────────────────────────────────────────
        ctl = tk.Frame(main, bg='#1a1a1a'); ctl.pack(fill=tk.X, pady=(0, 4))
        left = tk.Frame(ctl, bg='#1a1a1a'); left.pack(side=tk.LEFT)
        right = tk.Frame(ctl, bg='#1a1a1a'); right.pack(side=tk.RIGHT)
        
        btn_cfg = {'font': ('Arial', 11), 'relief': tk.FLAT,
                   'padx': 13, 'pady': 7, 'cursor': 'hand2'}
        
        self.start_btn = tk.Button(left, text="▶ Начать",
                                   font=('Arial', 11, 'bold'), relief=tk.FLAT,
                                   bg='#0e639c', fg='white', padx=15, pady=7,
                                   cursor='hand2')
        self.start_btn.pack(side=tk.LEFT, padx=3)
        
        self.new_btn = tk.Button(left, text="🔄 Новый текст",
                                 bg='#2d2d2d', fg='#cccccc', **btn_cfg)
        self.new_btn.pack(side=tk.LEFT, padx=3)
        
        self.font_btn = tk.Button(left, text="🔤 Шрифт",
                                  bg='#2d2d2d', fg='#cccccc', **btn_cfg)
        self.font_btn.pack(side=tk.LEFT, padx=3)
        
        self.book_btn = tk.Button(left, text="📖 Загрузить книгу",
                                  bg='#2d2d2d', fg='#4ec9b0', **btn_cfg)
        self.book_btn.pack(side=tk.LEFT, padx=3)
        
        self.lead_btn = tk.Button(right, text="🏆 Рекорды",
                                  bg='#2d2d2d', fg='#dcdcaa', **btn_cfg)
        self.lead_btn.pack(side=tk.RIGHT, padx=3)
        
        
        self._source_change_cb: Optional[Callable] = None

    # ── Настройка источников ──────────────────────────────────────────────────
    def set_sources(self, names: Dict[str, str]):
        self.source_panel.set_sources(names)

    def get_source_key(self) -> str:
        return self.source_panel.get_source_key()

    def get_size_key(self) -> str:
        return self.source_panel.get_size_key()

    def _on_source_change(self):
        if self._source_change_cb:
            self._source_change_cb()

    # ── Команды ───────────────────────────────────────────────────────────────
    def set_commands(self, start, new_text, leaderboard, book_cmd, source_change=None):
        self.start_btn.config(command=start)
        self.new_btn.config(command=new_text)
        self.lead_btn.config(command=leaderboard)
        self.book_btn.config(command=book_cmd)
        self.font_btn.config(command=self.show_font_dialog)
        self._source_change_cb = source_change

    # ── Ввод ──────────────────────────────────────────────────────────────────
    def bind_input(self, callback):
        self._hidden_entry.bind('<KeyPress>', callback)
        # Также биндим на главное окно для надёжности
        self.root.bind('<KeyPress>', self._root_key)
        self._key_callback = callback

    def _root_key(self, e):
        # Перенаправляем нажатие если Entry не в фокусе
        if self.root.focus_get() != self._hidden_entry:
            if self._key_callback:
                self._key_callback(e)

    def enable_input(self):
        self._hidden_entry.config(state=tk.NORMAL)
        self._hidden_entry.delete(0, tk.END)
        self._hidden_entry.focus_set()

    def disable_input(self):
        self._hidden_entry.config(state=tk.DISABLED)
        self.root.focus_set()

    def clear_input(self):
        self._hidden_entry.delete(0, tk.END)

    def set_running(self, v: bool):
        self.start_btn.config(
            text="⏸ Пауза" if v else "▶ Начать",
            bg='#5a4f10' if v else '#0e639c',
            fg='#dcdcaa' if v else 'white'
        )

    # ── Шрифт ─────────────────────────────────────────────────────────────────
    def show_font_dialog(self):
        FontDialog(self.root, self.current_font_size, self.set_font_size)

    def set_font_size(self, size: int):
        self.current_font_size = size
        self.work.set_font_size(size)
        # Адаптируем размер окна
        self.root.update_idletasks()
        new_h = max(560, 420 + size * 18)
        self.root.minsize(820, new_h)